package converter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {

    public List<String> getConfigElements(String line) {
        List<String> lineElementsList = new ArrayList<String>();
        String regex = "([^|]+)(?:\\|([^|]*))?(?:\\|([^|]*))?(?:\\|([^|]*))?(?:\\|([^|]*))?(?:\\|([^|]*))?";

        Pattern pattern = Pattern.compile(regex);
        Matcher sectionMatcher = pattern.matcher(line);

        if (sectionMatcher.matches()) {
            String value1 = sectionMatcher.group(1);
            String value2 = sectionMatcher.group(2) != null ? sectionMatcher.group(2).trim() : "null";
            String value3 = sectionMatcher.group(3) != null ? sectionMatcher.group(3).trim() : "null";
            String value4 = sectionMatcher.group(4) != null ? sectionMatcher.group(4).trim() : "null";
            String value5 = sectionMatcher.group(5) != null ? sectionMatcher.group(5).trim() : "null";
            String value6 = sectionMatcher.group(6) != null ? sectionMatcher.group(6).trim() : "null";

            value2 = value2.isEmpty() ? "null" : value2;
            value3 = value3.isEmpty() ? "null" : value3;
            value4 = value4.isEmpty() ? "null" : value4;
            value5 = value5.isEmpty() ? "null" : value5;
            value6 = value6.isEmpty() ? "null" : value6;

            lineElementsList.add(value1);
            lineElementsList.add(value2);
            lineElementsList.add(value3);
            lineElementsList.add(value4);
            lineElementsList.add(value5);
            lineElementsList.add(value6);
        }
        System.out.println(lineElementsList);
        return lineElementsList;
    }
}
