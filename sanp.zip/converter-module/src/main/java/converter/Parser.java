package converter;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Stack;

import org.json.JSONArray;
import org.json.JSONObject;

public class Parser {

    public JSONObject parseConfigFile(String configFilePath, String xmlFilePath) {
        RegularExpression regex = new RegularExpression();
        SearchTag searchTag = new SearchTag();
        ConvertJson convert = new ConvertJson();
        Split split = new Split();

        JSONObject result = new JSONObject();
        try (BufferedReader br = new BufferedReader(new FileReader(configFilePath))) {
            Stack<JSONObject> levelStack = new Stack<>();
            levelStack.push(result);

            String line;
            String listTag = "";
            while ((line = br.readLine()) != null) {

                if ((line.trim().startsWith("//")) || line.isEmpty() || line.startsWith("[")) {
                    continue;
                }

                List<String> lineElementsList = regex.getConfigElements(line);
                String jsonTag = lineElementsList.get(0);
                String xmlTag = lineElementsList.get(1);
                String dataStructure = lineElementsList.get(3);
                int level = Integer.parseInt(lineElementsList.get(2).split("_")[1]);
                while (levelStack.size() > level) {
                    levelStack.pop();
                }

                JSONObject parent = levelStack.peek();

                if (dataStructure != "null") {

                    if (dataStructure.equals("data")) {
                        String value = "";
                        if (lineElementsList.get(4) != "null") {
                            value = lineElementsList.get(4);
                        } else {
                            value = searchTag.searchTag(xmlTag, xmlFilePath);
                        }
                        parent.put(jsonTag, value);
                    }

                    else if (dataStructure.equals("list")) {
                        JSONArray list = new JSONArray();
                        listTag = jsonTag;
                        parent.put(jsonTag, list);
                    }

                    else if (dataStructure.equals("combination")) {
                        JSONObject combination = new JSONObject();
                        combination.put(jsonTag, new JSONArray());
                        parent.getJSONArray(listTag).put(combination);
                        levelStack.push(combination);
                    }

                    else if (dataStructure.equals("element")) {
                        if (lineElementsList.get(5) == "null") {
                            JSONObject element = new JSONObject();
                            String element_key = lineElementsList.get(0);
                            xmlTag = lineElementsList.get(1);
                            String element_value = "";

                            if (lineElementsList.get(4) != "null") {
                                element_value = lineElementsList.get(4);
                            } else {
                                element_value = searchTag.searchTag(xmlTag, xmlFilePath);
                            }

                            element.put(element_key, element_value);
                            JSONArray temp = parent.getJSONArray(listTag);
                            temp.put(element);
                        } else {
                            if (lineElementsList.get(5).equals("bi")) {

                                xmlTag = lineElementsList.get(1);
                                JSONArray columnsArray = new JSONArray();
                                JSONObject column = null;

                                String inputs = lineElementsList.get(4);
                                String[] inputsArray = inputs.split(",");
                                int inputs_iter = inputsArray.length;

                                for (int i = 1; i <= 2; i++) {
                                    String element_key = "column" + String.valueOf(i);
                                    if (i <= 1) {
                                        column = new JSONObject();
                                        column.put(element_key, inputsArray[i - 1]);
                                    } else {
                                        column = new JSONObject();
                                        if (lineElementsList.get(1).isEmpty()) {
                                            System.out.println(line);
                                        }
                                        String element_value = split.splitAndSearch(lineElementsList.get(1),
                                                xmlFilePath);
                                        if (inputs_iter > 1) {
                                            element_value = inputsArray[i - 1];
                                        }
                                        column.put(element_key, element_value);
                                    }
                                    columnsArray.put(column);
                                }
                                JSONObject elementsJsonObject = convert.convertToJson(columnsArray);
                                JSONArray temp = parent.getJSONArray(listTag);
                                temp.put(elementsJsonObject);
                            }
                        }
                    }

                } else {
                    JSONObject container = new JSONObject();
                    parent.put(jsonTag, container);
                    levelStack.push(container);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
