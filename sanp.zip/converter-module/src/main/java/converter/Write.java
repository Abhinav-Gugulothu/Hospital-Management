package converter;

import java.io.FileWriter;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Write {
    public void writeElementToXmlFile(Element xmlElement) {

        String filePath = "library\\xml_files\\inter.xml";

        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document newDoc = docBuilder.newDocument();
            Node importedNode = newDoc.importNode(xmlElement, true);
            newDoc.appendChild(importedNode);
            DOMSource source = new DOMSource(newDoc);
            FileWriter writer = new FileWriter(filePath);
            StreamResult result = new StreamResult(writer);
            transformer.transform(source, result);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
