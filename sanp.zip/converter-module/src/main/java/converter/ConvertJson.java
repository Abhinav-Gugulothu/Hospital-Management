package converter;

import org.json.JSONArray;
import org.json.JSONObject;

public class ConvertJson {
    public JSONObject convertToJson(JSONArray inputArray) {
        JSONObject outputObject = new JSONObject();

        for (int i = 0; i < inputArray.length(); i++) {
            JSONObject jsonObject = inputArray.getJSONObject(i);
            for (Object item : jsonObject.keySet()) {
                String key = item.toString();
                outputObject.put(key, jsonObject.get(key));
            }
        }

        return outputObject;
    }
}
