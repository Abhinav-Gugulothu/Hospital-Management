package converter;

import org.json.JSONObject;
import org.w3c.dom.*;

public class Main {
    public static void main(String[] args) {
        /// Using Linux then the path should be : home/gugulothua/archive/

        String xmlFilePath = "library\\xml_files\\sample.xml";
        String configFilePath = "library\\config_files\\amundi.cfg";
        String interXmlFilePath = "library\\xml_files\\inter.xml";
        String driverFilePath = "library\\json_files\\driver.json";

        FileCount fileCount = new FileCount();
        Loader loader = new Loader();
        GetElement get = new GetElement();
        Write write = new Write();
        Parser parse = new Parser();
        Driver driver = new Driver();
        Clean clean = new Clean();

        NodeList mainList = loader.loader(xmlFilePath);
        int count = fileCount.getFileCount(xmlFilePath);
        JSONObject elementJsonObject = null;
        clean.clean(driverFilePath);

        for (int i = 0; i < count; i++) {
            boolean finalElement = false;
            if (i == count - 1) {
                finalElement = true;
            }
            System.out.println("Cusomter : " + (i + 1));
            Element xmlElement = get.getElement(mainList, i);
            write.writeElementToXmlFile(xmlElement);
            elementJsonObject = parse.parseConfigFile(configFilePath, interXmlFilePath);
            driver.write(elementJsonObject, driverFilePath, finalElement);
        }

    }
}
