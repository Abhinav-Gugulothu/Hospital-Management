package converter;

import org.json.JSONObject;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Driver {
    public void write(JSONObject elementJsonObject, String driverFilePath, boolean finalElement) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(driverFilePath, true))) {
            if (finalElement) {
                String elementString = elementJsonObject.toString(4);
                writer.write(elementString);
                writer.newLine();
            } else {
                String elementString = elementJsonObject.toString(4);
                elementString += ",";
                writer.write(elementString);
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
