package converter;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Clean {
    public void clean(String driverFilePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(driverFilePath))) {
            writer.write("");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
