package converter;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;

public class Loader {
    public NodeList loader(String filePath) {
        NodeList finConfirmList = null;
        try {
            File inputFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            finConfirmList = doc.getElementsByTagName("FINCONFIRM");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finConfirmList;
    }
}
