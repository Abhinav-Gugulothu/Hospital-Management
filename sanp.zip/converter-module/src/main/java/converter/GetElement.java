package converter;

import org.w3c.dom.*;

public class GetElement {
    public Element getElement(NodeList finConfirmList, int item) {
        Element finConfirmElement = null;
        try {
            Node finConfirmNode = finConfirmList.item(item);
            if (finConfirmNode.getNodeType() == Node.ELEMENT_NODE) {
                finConfirmElement = (Element) finConfirmNode;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finConfirmElement;
    }
}
