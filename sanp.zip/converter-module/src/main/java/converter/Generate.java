package converter;

import java.io.FileWriter;
import org.json.JSONObject;

public class Generate {
    public void generate(JSONObject json) {
        /// home/gugulothua/converter/xml_files/
        String outputFilePath = "/home/gugulothua/converter/json_files/driver.json";
        try (FileWriter fileWriter = new FileWriter(outputFilePath)) {
            fileWriter.write(json.toString(4));
            System.out.println("JSON written to " + outputFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
