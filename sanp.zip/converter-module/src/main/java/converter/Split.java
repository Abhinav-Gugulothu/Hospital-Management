package converter;

public class Split {
    public String splitAndSearch(String xml_tags, String filePath) {
        String element_value = "";
        try {
            String[] xmlTagsArray = xml_tags.split(",");
            SearchTag searchTag = new SearchTag();

            for (String xmlTag : xmlTagsArray) {
                xmlTag = xmlTag.trim();
                if (!xmlTag.isEmpty()) {
                    String value = searchTag.searchTag(xmlTag, filePath);

                    if (!value.isEmpty()) {

                        element_value += value + "<cr>";
                    }
                }

            }
            if (!element_value.isEmpty()) {
                element_value = element_value.substring(0, element_value.length() - 4);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return element_value;
    }
}
