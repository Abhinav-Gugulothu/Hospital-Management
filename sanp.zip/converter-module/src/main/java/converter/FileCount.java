package converter;

public class FileCount {

    SearchTag searchTag = new SearchTag();

    public int getFileCount(String filePath) {
        int fileCount = 0;
        try {
            fileCount = Integer.parseInt(searchTag.searchTag("FILE_STATEMENT_COUNT", filePath));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileCount;
    }
}
